/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const createNote = `mutation CreateNote($input: CreateNoteInput!) {
  createNote(input: $input) {
    id
    title
    text
    createdAt
    updatedAt
  }
}
`;
export const updateNote = `mutation UpdateNote($input: UpdateNoteInput!) {
  updateNote(input: $input) {
    id
    title
    text
    createdAt
    updatedAt
  }
}
`;
export const deleteNote = `mutation DeleteNote($input: DeleteNoteInput!) {
  deleteNote(input: $input) {
    id
    title
    text
    createdAt
    updatedAt
  }
}
`;
